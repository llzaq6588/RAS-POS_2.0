#include <stdio.h>
#include <string.h>
#include <mysql/mysql.h> // Fedora 기준
#include "finish_cacul.h"
#include "change.h"
#include "recacul.h"
//공지사항 입력
#include "notis1.h"
#include "notis2.h"
#include "notis3.h"





int main()
{
    system("clear");
    notis1();
    notis2();
    notis3();

    MYSQL *connect; //연결설정
//-----------------------------------결과 반환시 날것과 가공 통조림이 필요---------
    MYSQL_ROW row_1; //코드 서치 데이터 날것
    MYSQL_RES *res_1; //코드 서치 데이터 통조림
    MYSQL_ROW row_3; //sell 데이터 날것
    MYSQL_RES *res_3; //sell 데이터 통조림
    MYSQL_ROW row_4; //sell 총 합의 날것
    MYSQL_RES *res_4; //sell 총 합의 통조림

//------------직접 쿼리를 넣기보다 sprint가 안전하겠지 ㅎㅎ--------------------
    char qbuf_0[200]; // 장바구니 만들기
    char qbuf_1[200]; // 코드 서치 데이터 쿼리
    char qbuf_2[200];// sell에 입력하는 쿼리
    char qbuf_3[200];// sell 데이터 보여주기
    char qbuf_4[200];// sell의 총합 보여주기
    char qbuf_5[200];// if == "finish"<일명 계산끝> sold_book으로 입력
    char qbuf_6[200];// if == "finish" sell drop
    char qbuf_7[200];
    char code[20];
    

//------------------------DB접속------------------------------
    connect = mysql_init(NULL); 
    connect = mysql_real_connect(connect,"localhost","raspos","raspospw","raspos",0,NULL,0);

//------------------------장바구니(sell)을 만들자-------------    
    sprintf(qbuf_0, "CREATE TABLE sell (name text, price int(11))");
    mysql_query(connect, qbuf_0);
    

    
    
while(1)
{
    while(1)
    {
        system("clear");
        //-------------------------------------sell 결과 출력----------------------
        sprintf(qbuf_3, "SELECT * FROM sell");
        mysql_query(connect, qbuf_3);
        res_3=mysql_store_result(connect);
        printf("===========================================================\n");
        printf("[            이름           ||            가격            ]\n");
        printf("===========================================================\n");
        while(row_3=mysql_fetch_row(res_3))
        {
        printf("[        %s                       %s원          ]\n", row_3[0], row_3[1]);
        }
        printf("===========================================================\n");

        //-------------------------------------sell의 총합 출력---------------------
        sprintf(qbuf_4, "SELECT sum(price) FROM sell");
        mysql_query(connect, qbuf_4);
        res_4=mysql_store_result(connect);
        row_4=mysql_fetch_row(res_4);
        printf("[                  총     합               ||    %s원  ]", row_4[0]);
        printf("\n==========================================================\n");
        printf("[ 1 : 계산완료 | 2 : 거스름돈| 3 : 다시계산| + : 물건개수]\n");
        printf("==========================================================\n\n");
        
        printf("             상 품 코 드  입 력 : ");
        scanf("%20s", code);

        //-----------------------------------계산 끝!!!----------------------
        if(strcmp(code, "1") == 0)
        {
           finish_cacul();            
           mysql_query(connect, "CREATE TABLE sell (name text, price int(11))");
            
           char nothing[10];
           gets(nothing);
           
           system("clear");
           //계산이 끝이 날 경우에는 해당 영역에서 완전히 벗어나게 된다.
           break;
        }
        
        if(strcmp(code, "2") == 0)
        {
            change();
            mysql_query(connect, "CREATE TABLE sell (name text, price int(11))");
            
            char nothing2[10];

            gets(nothing2);
            system("clear");
            
            
            break;
        }

        if(strcmp(code, "3") == 0)// 계산이 틀렸을 경우이다.
        {
            recacul();
            mysql_query(connect, "CREATE TABLE sell (name text, price int(11))"); //사라진 장바구니는 다시 만들고
            char nothing3[10];

            gets(nothing3);
            system("clear");
            break; 
        }

        if((atoi(code) >= 5) && (atoi(code) <= 1000000))
        {
            sprintf(qbuf_7, "INSERT INTO sell(name,price) VALUES('추가가격',%s)", code);
            mysql_query(connect,qbuf_7);
            break;
        }



        if(strcmp(code, "+") == 0)
        {
           system("clear");
           int num;
           printf("\n\n     ================================================");
           printf("\n     [                                              ]");
           printf("\n     [          몇 개 를 구 입 하 셨 나 요 ?        ]");
           printf("\n     [                                              ]");
           printf("\n     ================================================");
           printf("\n\n         상 품 개 수 :  ");
           scanf("%i", &num);
           printf("\n\n     ================================================\n");

           num = num - 1;
           mysql_query(connect, qbuf_1);

//--------------------------------------코드 검색결과 sell테이블 입력-------
           res_1=mysql_store_result(connect);
           row_1=mysql_fetch_row(res_1);
           int i;
           for(i=0; i<num; i++)
           {
               sprintf(qbuf_2, "INSERT INTO sell(name,price) VALUES('%s',%s)", row_1[2], row_1[3]);
               mysql_query(connect,qbuf_2);
           }
       }



       else// 그 외에 정상적인 반복문
       {
           sprintf(qbuf_1, "select * from price where code = '%s'", code);
           mysql_query(connect, qbuf_1); 

//--------------------------------------코드 검색결과 sell테이블 입력-------
           res_1=mysql_store_result(connect);
           row_1=mysql_fetch_row(res_1);
           sprintf(qbuf_2, "INSERT INTO sell(name,price) VALUES('%s',%s)", row_1[2], row_1[3]);
           mysql_query(connect,qbuf_2);
       }
    }
       
}
//-------------------------------메모리가 많지 않는 이상 놓아주거라------------
    mysql_free_result(res_1);
    mysql_free_result(res_3);
    mysql_free_result(res_4);
    mysql_close(connect);

    return 0;
    
}
