#include <stdio.h>
#include "notis2.h"

int notis2()
{                  

    system("clear");   
    printf("[---------------------------------------------------------]\n");
    printf("[                                                         ]\n");
    printf("[                 설치 전 주의사항                        ]\n");
    printf("[                                                         ]\n");
    printf("[      기존 raspos 1.5 ver이 깔려 있어야 합니다.          ]\n");
    printf("[      아니면 세그멘테이션 오류가 쾅쾅!!!                 ]\n");
    printf("[      상품관리는 웹을 통해 이루어집니다.                 ]\n");
    printf("[      본 프로그램의 설치는 파일 내의 PDF를 참조하세요.   ]\n");
    printf("[                                                         ]\n");
    printf("[---------------------------------------------------------]\n");
    

    printf("\n     다음을 보시려면 ENTER을 눌러주세요.");
    
    char stay[2];
    gets(stay);                                                                                                                  
}
