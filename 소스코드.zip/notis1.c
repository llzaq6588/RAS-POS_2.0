#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "notis1.h"

int notis1()
{                  
    system("clear");
    printf("[---------------------------------------------------------]\n");
    printf("[                   raspos 2.0 CUI ver                    ]\n");
    printf("[---------------------------------------------------------]\n");
    printf("[                                                         ]\n");
    printf("[ 안녕하세요. 라즈베리파이 가족 여러분!! ^^               ]\n");
    printf("[ 저번에 올려주신 피드백을 바탕으로 RASPOS C 기반 작업이  ]\n");
    printf("[ 진행되었고 결과 드디어 만족할만한 결과물이 나왔습니다.  ]\n");
    printf("[ GUI는 계속 작업중입니다만.... 역시 어렵네요. ㅎㅎ       ]\n");
    printf("[ 현재 GTK+와 glade를 파고 있습니다. ㅎㅎ                 ]\n");
    printf("[ 추후 완벽한 GUI를 가지고 다시 찾아뵙겠습니다.           ]\n");
    printf("[ 많은 피드백 부탁드립니다.                               ]\n");
    printf("[                                                         ]\n");
    printf("[                                       - KAERIUS -       ]\n");
    printf("[---------------------------------------------------------]\n");
    printf("     다음을 보시려면 ENTER을 눌러주세요.");

    char stay[2];
    gets(stay);
}
