#include <stdio.h>
#include <string.h>
#include <mysql/mysql.h> // Fedora 기준
#include "recacul.h"

int recacul()
{

    MYSQL *connect; //연결설정

    //------------------------DB접속------------------------------
    connect = mysql_init(NULL);
    connect = mysql_real_connect(connect,"localhost","raspos","raspospw","raspos",0,NULL,0);



    mysql_query(connect, "DROP TABLE sell");

    system("clear");
    printf("\n\n\n     ================================================\n");
    printf("     [                                              ]\n");
    printf("     [             다 시 계 산 합 니 다 .           ]\n");
    printf("     [                                              ]\n");
    printf("     ================================================\n");
    printf("\n     계속하시려면 ENTER을 눌러주세요.");

    char stay[2];
    gets(stay);
    
}
