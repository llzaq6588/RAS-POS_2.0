#include <stdio.h>
#include <string.h>
#include <mysql.h>
#include <time.h>
#include "finish_cacul.h"

//int main()
int finish_cacul()
{

    MYSQL *connect; //연결설정

    MYSQL_ROW row_4; //sell 총 합의 날것
    MYSQL_RES *res_4; //sell 총 합의 통조림


    char qbuf_5[200];// if == ""<일명 계산끝> sold_book으로 입력

    connect = mysql_init(NULL);
    connect = mysql_real_connect(connect,"localhost","raspos","raspospw","raspos",0,NULL,0);


        mysql_query(connect, "SELECT sum(price) FROM sell");
        res_4=mysql_store_result(connect);
        row_4=mysql_fetch_row(res_4);


    

    //--------------------------판매 년도 출력--------
    time_t ltime; //현제시간을 구하는 식. sold_book에 같이 입력된다.
    struct tm *today;

    time(&ltime);
    today = localtime(&ltime);
    
    sprintf(qbuf_5, "INSERT INTO sold_book (year, yearmonth, sellday, time, totalprice) VALUES('%04d', '%04d-%02d', '%04d-%02d-%02d', '%02d:%02d:%02d', '%s')", today->tm_year + 1900, today->tm_year + 1900, today->tm_mon + 1, today->tm_year + 1900, today->tm_mon + 1, today->tm_mday, today->tm_hour, today->tm_min, today->tm_sec, row_4[0]);

    mysql_query(connect, qbuf_5);

    system("clear");
    printf("\n\n\n     ================================================");
    printf("\n     [                                              ]");
    printf("\n     [             구 매 감 사 합 니 다             ]");
    printf("\n     [                                              ]");
    printf("\n     [  현재시간 : %04d-%02d-%02d %02d:%02d:%02d              ]", today->tm_year + 1900, today->tm_mon + 1, today->tm_mday, today->tm_hour, today->tm_min, today->tm_sec);
    printf("\n     [                                              ]");
    printf("\n     [                         판매가격 : %s원   ]", row_4[0]);
    printf("\n     [                                              ]");
    printf("\n     ================================================");
    printf("\n\n     계속하시려면 ENTER을 눌러주세요.");
    char stay[2];
    gets(stay);


    mysql_query(connect, "DROP TABLE sell");

}
