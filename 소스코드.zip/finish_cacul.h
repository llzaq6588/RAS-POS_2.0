int finish_cacul();
